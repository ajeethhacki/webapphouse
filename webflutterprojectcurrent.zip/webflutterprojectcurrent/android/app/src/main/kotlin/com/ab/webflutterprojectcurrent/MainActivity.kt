package com.ab.webflutterprojectcurrent

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
